import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const dir=dirname(fileURLToPath(import.meta.url));
const expectationPath=resolve(dir,'whole04-source-qualified-expectation.json');
const hash=value=>createHash('sha256').update(value).digest('hex');
const load=path=>JSON.parse(readFileSync(path,'utf8'));
const expectation=load(expectationPath);
function qualified(ref){assert.equal(hash(readFileSync(ref.path)),ref.sha256);return load(ref.path);}
const original=qualified(expectation.original_world_ref);
const portable=qualified(expectation.retained_portable_ref);
const rawOriginal=original.response.outcome.data.source.world;
const base=resolve(dir,'../../whole-replay-04/runtime-e254-29d5296a-ql70-reviewed-profile');
const currentPath=resolve(base,'direct-native-operation-4.json');
const currentRawPath=resolve(base,'direct-native-operation-4.raw.json');
const current=load(currentPath);
const rawCurrent=current.response.outcome.data.source.world;

function exact(actual,expected,path='$'){
 // Compare in place; retain only the first differing path. No recursive
 // comparison copies or enormous assertion diffs are materialized.
 if(typeof actual!==typeof expected)throw new Error('type differs at '+path);
 if(typeof actual==='number'){
  if(!Number.isFinite(actual)||!Number.isFinite(expected)||actual!==expected)throw new Error('number differs at '+path);
  return; // The sole declared signed-zero storage distinction compares equal.
 }
 if(actual===null||expected===null){if(actual!==expected)throw new Error('null differs at '+path);return;}
 if(Array.isArray(actual)||Array.isArray(expected)){
  if(!Array.isArray(actual)||!Array.isArray(expected)||actual.length!==expected.length)throw new Error('array shape differs at '+path);
  for(let i=0;i<actual.length;i++)exact(actual[i],expected[i],path+'['+i+']');return;
 }
 if(typeof actual==='object'){
  const keys=Object.keys(actual).sort(),other=Object.keys(expected).sort();
  if(keys.length!==other.length||keys.some((key,i)=>key!==other[i]))throw new Error('fields differ at '+path);
  for(const key of keys)exact(actual[key],expected[key],path+'.'+key);return;
 }
 if(actual===undefined||actual!==expected)throw new Error('value differs at '+path);
}
function buffers(world){
 assert.deepEqual(portable.record.runtime_buffers.buffers.map(b=>b.key).sort(),['slots_a','slots_b']);
 return portable.record.runtime_buffers.buffers.map(buffer=>{
  const values=world.binding.presentation[buffer.key];assert.ok(Array.isArray(values));
  assert.equal(values.length,buffer.values);assert.equal(values.length,expectation.required_buffer_guard.count_per_key);
  assert.equal(hash(JSON.stringify(values)),buffer.json_sha256);assert.equal(buffer.json_sha256,expectation.required_buffer_guard.json_sha256_per_key);
  for(let i=0;i<values.length;i++)assert.equal(values[i],i%4096);
  return {key:buffer.key,count:values.length,json_sha256:hash(JSON.stringify(values))};
 });
}
function verifyOriginal(world){
 assert.deepEqual(Object.keys(world).sort(),expectation.complete_world_keys);
 assert.deepEqual(world.native_owner_sources,expectation.expected_original_native_owner_sources);
 assert.deepEqual(world.sky_admission,expectation.expected_original_sky_admission);
 assert.deepEqual(world.sky.source_binding,expectation.expected_exact_legacy_source_binding);
 buffers(world);
}
function verifyCurrent(world){
 assert.deepEqual(Object.keys(world).sort(),expectation.complete_world_keys,'Complete world fields classified exactly');
 assert.deepEqual(world.native_owner_sources,expectation.expected_native_owner_sources,'Complete Git70 owner tuples and exact role set');
 assert.deepEqual(world.sky_admission,expectation.expected_retained_sky_admission,'Exact source-derived retained admission');
 for(const key of expectation.semantic_world_keys)exact(world[key],rawOriginal[key],key);
 exact(world.sky,rawOriginal.sky,'immutable-sky');
 exact(world.basis,world.binding.native_basis);exact(world.event,world.basis.input);
 exact(world.scene,world.binding.scene);exact(world.native_readback,world.binding.native_readback);
 buffers(world);
}
verifyOriginal(rawOriginal);
const decoded=structuredClone(portable.record.world);
assert.equal(decoded.schema,'oi.epi-portable-world/v1');
assert.equal(decoded.native_owner_sources.length,3);
decoded.schema='ql.scene-world/v1';
decoded.native_owner_sources=Object.fromEntries(decoded.native_owner_sources.map(source=>[source.role,source.reading]));
for(const key of ['slots_a','slots_b'])decoded.binding.presentation[key]=rawOriginal.binding.presentation[key];
exact(decoded,rawOriginal,'complete-original-portable-native-custody');
verifyCurrent(rawCurrent);
exact(load(currentRawPath),current.response,'raw-parsed-signed-zero-only');
exact(current.response.outcome.data.binding,rawCurrent.binding);
assert.equal(current.request.request.request.snapshot_purpose,'retained-occasion');
exact(current.request.request.request.sky_snapshot,rawOriginal.sky);
assert.ok(!current.response.outcome.data.lease&&!current.response.outcome.data.receipt);
const ql=expectation.managed_all_five.find(binary=>binary.name==='ql');
assert.equal(current.response.outcome.data.source.ql_executable_sha256,ql.sha256);
assert.equal(current.response.outcome.data.source.ql_executable,ql.path);
assert.equal(current.response.outcome.data.source.ql_selection,'operator-override');
assert.equal(current.response.outcome.data.source.ql_revision,null);

const mutations=[];
let peakRSS=process.memoryUsage().rss;
function reject(name,mutate,original=false){
 const copy=structuredClone(original?rawOriginal:rawCurrent);mutate(copy);
 assert.throws(()=>original?verifyOriginal(copy):verifyCurrent(copy),name+' must refuse');
 mutations.push({name,result:'refused',scope:'copied retained real data; verifier qualification only'});
 peakRSS=Math.max(peakRSS,process.memoryUsage().rss);
 if(globalThis.gc)globalThis.gc();
}
reject('missing world schema',w=>delete w.schema);
reject('wrong world schema',w=>w.schema='ql.scene-world/v2');
reject('unclassified extra top-level field',w=>w.unclassified_native_state={value:1});
reject('missing whole semantic field',w=>delete w.current_form);
function firstNumber(value,path=[]){
 if(typeof value==='number')return path;
 if(value&&typeof value==='object')for(const key of Object.keys(value)){const found=firstNumber(value[key],[...path,key]);if(found)return found;}
 return null;
}
function at(value,path){for(const key of path)value=value[key];return value;}
const numberPath=firstNumber(rawCurrent.event);assert.ok(numberPath?.length);
reject('changed actual semantic numerical determinant',w=>{const parent=at(w.event,numberPath.slice(0,-1)),key=numberPath.at(-1);parent[key]+=1;});
reject('nonfinite semantic determinant',w=>{const parent=at(w.event,numberPath.slice(0,-1)),key=numberPath.at(-1);parent[key]=NaN;});
reject('missing source-bearing array member',w=>w.registers.degree.pop());
reject('changed original sky astronomical quantity',w=>w.sky.bodies[0].longitude_degrees+=0.001);
reject('wrong original sky mode',w=>w.sky.request.mode='historical');
reject('generic legacy provider exception',w=>w.sky.provider.adapter_sha256='0'.repeat(64));
reject('old unqualified registry exception',w=>w.sky.source_binding.registry_revision='0'.repeat(64));
for(const [name,mutate] of [
 ['unknown current owner hash',w=>w.native_owner_sources.field.revision='sha256:'+'0'.repeat(64)],
 ['unavailable owner',w=>w.native_owner_sources.field.availability='unavailable'],
 ['wrong current owner source address',w=>w.native_owner_sources.field.ref='crates/ql-mef/src/other.rs'],
 ['missing current owner role',w=>delete w.native_owner_sources.coupled],
 ['extra current owner role',w=>w.native_owner_sources.extra=structuredClone(w.native_owner_sources.field)],
 ['unknown current reading field',w=>w.native_owner_sources.field.unqualified=true],
 ['legacy field hash stamped onto current owner',w=>w.native_owner_sources.field.revision=expectation.expected_original_native_owner_sources.field.revision],
 ['retained occasion falsely fresh',w=>w.sky_admission.fresh_current_attested=true],
 ['retained purpose changed',w=>w.sky_admission.purpose='requested'],
 ['admission original mode changed',w=>w.sky_admission.original_mode='historical'],
 ['admission epoch changed',w=>w.sky_admission.epoch_utc='2026-09-28T00:00:00Z'],
 ['admission receipt changed',w=>w.sky_admission.receipt_utc='2026-09-28T00:00:00Z'],
 ['admission snapshot changed',w=>w.sky_admission.snapshot_ref='sha256:'+'0'.repeat(64)],
 ['unknown validator hash',w=>w.sky_admission.validator_source.revision='sha256:'+'0'.repeat(64)],
 ['unknown validator address',w=>w.sky_admission.validator_source.source_ref='providers/sky/other.py'],
 ['unknown admission field',w=>w.sky_admission.accept_other_legacy=true],
 ['missing exact legacy qualifier',w=>delete w.sky_admission.source_binding_qualification],
 ['qualifier falsely fresh',w=>w.sky_admission.source_binding_qualification.fresh_current_attested=true],
 ['wrong legacy provider qualifier',w=>w.sky_admission.source_binding_qualification.provider_adapter_sha256='0'.repeat(64)],
 ['wrong legacy descriptor qualifier',w=>w.sky_admission.source_binding_qualification.original_sun_role='other-legacy'],
 ['unknown qualifier field',w=>w.sky_admission.source_binding_qualification.generic_exception=true],
 ['Sun routed to wrong canonical centre',w=>w.sky_admission.source_binding_qualification.native_sun_route.chakra_coordinate='#2-5-0/1-6'],
 ['wrong native route typed ID',w=>w.sky_admission.source_binding_qualification.native_sun_route.planet_id='0'.repeat(16)],
 ['wrong native route source revision',w=>w.sky_admission.source_binding_qualification.native_sun_route.source_revision='0'.repeat(64)],
 ['Sun relation direction reversed',w=>w.sky_admission.source_binding_qualification.native_sun_route.relations[0].orientation='undirected'],
 ['wrong Sun relation kind',w=>w.sky_admission.source_binding_qualification.native_sun_route.relations[0].source_kind='HAS_CHAKRAL_ANCHOR'],
 ['missing Sun directed relation',w=>w.sky_admission.source_binding_qualification.native_sun_route.relations=[]],
 ['extra unqualified Sun relation',w=>w.sky_admission.source_binding_qualification.native_sun_route.relations.push(structuredClone(w.sky_admission.source_binding_qualification.native_sun_route.relations[0]))],
 ['native buffer identity changed',w=>w.binding.presentation.slots_a[4096]=1],
 ['native second buffer member missing',w=>w.binding.presentation.slots_b.pop()],
 ['native first buffer absent',w=>delete w.binding.presentation.slots_a],
])reject(name,mutate);
reject('original field owner relabelled to successor',w=>w.native_owner_sources.field=structuredClone(expectation.expected_native_owner_sources.field),true);
reject('original requested admission rewritten as retained',w=>w.sky_admission=structuredClone(expectation.expected_retained_sky_admission),true);

const report={schema:'epi.whole04-independent-verifier-qualification/v1',passed:true,
 scope:'Offline qualification of source-derived expectation and guards against retained actual original24/whole04 artifacts. No new native operation, browser, build, install, provider, model or causal receiving claim.',
 expectation:{path:expectationPath,sha256:hash(readFileSync(expectationPath))},
 verifier:{path:fileURLToPath(import.meta.url),sha256:hash(readFileSync(fileURLToPath(import.meta.url)))},
 original:expectation.original_world_ref,portable:expectation.retained_portable_ref,
 actual_current:{path:currentPath,sha256:hash(readFileSync(currentPath))},actual_current_raw:{path:currentRawPath,sha256:hash(readFileSync(currentRawPath))},
 complete_world_keys:expectation.complete_world_keys,exact_semantic_keys:expectation.semantic_world_keys,
 buffers:buffers(rawCurrent),current_owner:rawCurrent.native_owner_sources,
 admission:rawCurrent.sky_admission,actual_native_selection:{selection:'operator-override',revision:null,managed_binary_sha256:ql.sha256},
 negative_count:mutations.length,mutations,
 resource_scope:{heap_limit_mib:192,comparison:'in-place exact first-difference; no normalized copies or full-data assertion diffs',peak_observed_rss_bytes:peakRSS},
 native_acceptance:false,installed_acceptance:false,H:false};
const path=resolve(dir,'verifier-qualification.json');writeFileSync(path,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({passed:true,path,sha256:hash(readFileSync(path)),exact_semantic_keys:14,negative_count:mutations.length,scope:report.scope}));
